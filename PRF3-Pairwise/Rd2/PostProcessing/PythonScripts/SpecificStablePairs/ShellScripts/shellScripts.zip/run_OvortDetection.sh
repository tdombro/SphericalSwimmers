#!/bin/sh        

ReList="0.5 2.0 3.0 5.0 10.0 15.0 30.0"
pairList="O"
perNumber="5 10 15 20 25 50 100"
local="0"

for pair in $pairList
do
    echo $pair
    for Re in $ReList
    do
	echo 'Re='$Re
	for per in $perNumber
	do

	    echo $pair': Re'$Re': per='$per
	    sbatch -J 'DetectW_'$pair'_Re'$Re'_per_'$per'_' -t 1-0 -n 1 -p general -o '%x.out' --mem-per-cpu=10000 scriptVortDetection.sh $pair $Re $per $local
	done
    done
done
