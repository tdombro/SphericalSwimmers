#!/bin/sh

config=$1
Re=$2
per=$3
local=$4

python3 VortexDetection_1osc.py $config $Re $per $local
