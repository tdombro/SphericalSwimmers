#!/bin/sh        

configList="V O SF HB"
ReList="0.5 5.0 10.0 20.0 35.0"
perNumber="5 10 50 100"
local="0"

for config in $configList
do
    for Re in $ReList
    do
	echo 'Re='$Re
	for per in $perNumber
	do
	    echo $config': Re'$Re': per='$per
	    sbatch -J 'DetectW_'$config'_Re'$Re'_per'$per'_' -t 1-0 -n 1 -p general -o '%x.out' --mem-per-cpu=10000 scriptVortDetection.sh $config $Re $per $local
	done
    done
done

