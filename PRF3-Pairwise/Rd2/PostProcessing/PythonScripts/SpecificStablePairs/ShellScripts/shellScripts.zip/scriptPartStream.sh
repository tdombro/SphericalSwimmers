#!/bin/sh

pair=$1
Re=$2
per=$3

python3 ParticleStreamline_1osc.py $pair $Re $per
