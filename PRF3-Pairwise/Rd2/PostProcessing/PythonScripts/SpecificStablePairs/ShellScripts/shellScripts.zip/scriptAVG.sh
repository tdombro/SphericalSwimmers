#!/bin/sh

Re=$2
Config=$1

python3 $PWD/ExportAverageFieldData.py $Config $Re
