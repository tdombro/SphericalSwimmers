#!/bin/sh        

RList="3 4 5"
ThetaList="0 1 2 3"
ConfigList="Parallel Perp"
ReList="SSL LSL Stat"

for R in $RList
do
    echo $R"R"
    cd $R
    for Theta in $ThetaList
    do
	echo "PI"$Theta
	cd PI$Theta
	for Config in $ConfigList
	do
	    echo $Config
	    cd $Config
	    for Re in $ReList
	    do
		echo $Re
		mv $Re'pd.txt' $Re/pd.txt
                #mkdir -p $R'/PI'$Theta'/'$Config'/'$Re
		#sbatch -J $R'R_PI'$Theta'_'$AoP'_'$SSLoLSL scriptVelViz.sh $R $Theta $AoP $SSLoLSL
	    done
	    cd ../
	done
	cd ../
    done
    cd ../
done
