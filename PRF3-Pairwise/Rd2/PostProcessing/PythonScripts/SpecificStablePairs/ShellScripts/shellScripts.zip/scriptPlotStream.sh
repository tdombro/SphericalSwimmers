#!/bin/sh

pair=$1
Re=$2
timeVTK=$3

python3 GenerateFig4_Streams_Rotated_1osc.py $pair $Re $timeVTK
