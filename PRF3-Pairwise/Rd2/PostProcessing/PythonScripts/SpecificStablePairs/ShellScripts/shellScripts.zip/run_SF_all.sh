#!/bin/sh        

ReList="20.0 35.0"

for Re in $ReList
do
    echo "Re"$Re
    if [ "$Re" == "20.0" ]; then
	echo "Re="$Re
	timeVTK="15.0"
    elif [ "$Re" == "35.0" ]; then
        echo "Re="$Re
	timeVTK="10.0"
    else
	echo "I messed up"
    fi
    echo "time="$timeVTK
    #sbatch -J 'ExtractVTK_SF_Re'$Re -t 1-0 -n 1 -p general -o '%x.out' scriptVisit.sh $Re 'SF' $timeVTK
    #sbatch -J 'AvgVTK_SF_Re'$Re -t 1-0 -n 1 -p general -o '%x.out' scriptAVG.sh $Re 'SF' $timeVTK
    sbatch -J 'PlotRotStream_SF_Re'$Re'_' -t 1-0 -n 1 -p general -o '%x.out' --mem-per-cpu=10000 scriptPlotStream.sh 'SF' $Re $timeVTK
done
