#!/bin/sh

pair=$1
Re=$2

python3 PlotFig4_ForceTerms_1osc.py $pair $Re
