#!/bin/sh

RE_VALUE="0.5 0.6 0.7 0.8 0.9 1.0 2.0 3.0 4.0 5.0 5.5 6.0 6.5 7.0 7.5 10.0 12.5 15.0 17.5 20.0 25.0 30.0 35.0 40.0 50.0 60.0"

for Re in $RE_VALUE
do
    scp 'tdombro@longleaf.unc.edu:/pine/scr/t/d/tdombro/Spherobot/SingleBot/Pairwise/SweepRe/Re'$Re'/pd.txt' 'pd_Re'$Re'.txt'
    #cd 'SweepRe/Re'$Re
    #sbatch script.sh
    #cd ../../
done
