#!/bin/sh        

ReList="0.5 5.0 10.0 20.0 35.0"
pairList="SF O HB V"
#pairList="SF"
#ReList="20.0 35.0"

for pair in $pairList
do
    echo $pair
    for Re in $ReList
    do
	echo 'Re='$Re

	if [ "$pair" == "SF" ]; then
	    if [ "$Re" == "20.0" ]; then
		echo "Re="$Re
		timeVTK="15.0"
	    else
		timeVTK="10.0"
	    fi
	else
	    timeVTK="10.0"
	fi
	echo 'time='$timeVTK
	#sbatch -J 'PlotAVG_'$pair'_Re'$Re'_' -t 1-0 -n 1 -p general -o '%x.out' scriptPlotAVG.sh $pair $Re
	#sbatch -J 'PlotRotStream_'$pair'_Re'$Re'_' -t 1-0 -n 1 -p general -o '%x.out' scriptPlotStream.sh $pair $Re
	#sbatch -J 'PlotForce_'$pair'_Re'$Re'_' -t 0-1 -n 1 -p general -o '%x.out' scriptPlotForce.sh $pair $Re
	sbatch -J 'PlotVelDecay_'$pair'_Re'$Re'_' -t 1-0 -n 1 -p general -o '%x.out' --mem-per-cpu=10000 scriptPlotVelDecay.sh $pair $Re $timeVTK

    done
done
