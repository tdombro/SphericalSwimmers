#!/bin/sh        

ReList="0.1 0.3"
pairList="V"

for pair in $pairList
do
    echo $pair
    for Re in $ReList
    do
	echo $pair': Re'$Re': per='$per
	sbatch -J 'ExportAVG_'$pair'_Re'$Re'_' -t 1-0 -n 1 -p general -o '%x.out' scriptAVG.sh $pair $Re
	
    done
done
