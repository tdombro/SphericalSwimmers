#!/bin/sh        

RList="5 6 7"
ThetaList="0 1 2 3 4"
ConfigList="Anti Parallel PerpL PerpS"
ReList="SSL LSL Stat"

for R in $RList
do
    echo $R"R"
    for Theta in $ThetaList
    do
	echo "PI"$Theta
	for Config in $ConfigList
	do
	    echo $Config
	    for Re in $ReList
	    do
		echo $Re
		mkdir -p $R'/PI'$Theta'/'$Config'/'$Re
		#sbatch -J $R'R_PI'$Theta'_'$AoP'_'$SSLoLSL scriptVelViz.sh $R $Theta $AoP $SSLoLSL
	    done
	done
    done
done
